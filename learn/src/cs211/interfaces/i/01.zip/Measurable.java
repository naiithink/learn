package cs211;

@FunctionalInterface
public interface Measurable<T> {

    T measure();
}
