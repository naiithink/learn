package cs211.interfaces.ii.i;

public class Product {

    private String name;

    private double price; // ราคา

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}
