package cs211.interfaces.ii.i;

public class Car {

    private String license;

    private double kiloDriven; // ระยะทางการขับ

    public String getLicense() {
        return license;
    }

    public double getKiloDriven() {
        return kiloDriven;
    }
}
