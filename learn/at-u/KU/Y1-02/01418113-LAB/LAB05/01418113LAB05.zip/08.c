#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    printf("Input number of stairs: ");

    return 0;
}