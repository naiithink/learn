#include <stdio.h>

int main()
{
    int n, i, j;
    printf("Enter the number of rows or columns: ");
    scanf("%d", &n);
    int a[n][n];

    // Assign value to array a
    /* sec 1 --- */

    /* sec 1 ... */

    // Print all values in array a
    for (/**/  /**/)
    {
        for (/**/  /**/)
            printf(/**/"  "/**/, a/**/  /**/);
        printf("\n");
    }
    return 0;
}