Multi-line Text Blanks
===================

This is a test for multi-line blanks inside regular text.

Answer the following questions
------------------------------

* Give a brief history of elab

{{ xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx }}

* What are advantages and disadvantages of elab?

{{ xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx }}
