Code with Blanks
================

This is for testing a code block with blanks.

::elab:begincode language="python3"
name = input({{"Enter your name: "}})
{{print(f"Hello, {name}")}}
::elab:endcode
