Text Blanks
===========

This is a test for blanks inside regular text.

* What is the year with the big flood? {{2011}}
* How old is the earth? {{4.543 billion years}}
