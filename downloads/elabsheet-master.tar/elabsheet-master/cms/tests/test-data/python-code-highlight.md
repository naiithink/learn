Python Code
===========

This is for testing a Python code block.

::elab:begincode language="python3"
name = input("Enter your name: ")
print(f"Hello, {name}")
::elab:endcode
