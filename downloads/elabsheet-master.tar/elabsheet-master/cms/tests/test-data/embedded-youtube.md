Test Video Embedding
=====================

First Video
-----------
<center>
::elab:embed media="youtube:H1d6OeujEdo"
</center>

Second Video
------------
::elab:embed media="youtube:LXGtE3X2k7Y"
