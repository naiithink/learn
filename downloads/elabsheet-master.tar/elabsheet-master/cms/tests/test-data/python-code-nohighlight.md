Python Code
===========

This is for testing a Python code block.

::elab:begincode language=None
name = input("Enter your name: ")
print(f"Hello, {name}")
::elab:endcode
