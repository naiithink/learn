Hello
=====

This is an equation.

\[ x^2 = x - 1. \]

This equation, \(a+b=\sqrt{c}\), is inline.

