Test cases
----------

Enclose each *input* in `::elab:begintest` and `::elab:endtest`.  For
example,

    ::elab:begintest
    10
    ::elab:endtest

The system will generate the output from the solution in the source.
For the above input, the output generated is `110`.
