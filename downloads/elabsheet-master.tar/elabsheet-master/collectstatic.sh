./manage.py collectstatic_js_reverse
./manage.py collectstatic
