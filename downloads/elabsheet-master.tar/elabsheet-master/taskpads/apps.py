from django.apps import AppConfig


class TaskpadsConfig(AppConfig):
    name = 'taskpads'
