from django.apps import AppConfig


class InstrConfig(AppConfig):
    name = 'instr'

