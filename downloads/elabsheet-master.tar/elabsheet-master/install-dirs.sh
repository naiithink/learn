#!/bin/bash

echo 'Setting up necessary directories...'
mkdir -p tmp/elab
mkdir -p public/media/supplements
chmod a+rwx tmp/elab
