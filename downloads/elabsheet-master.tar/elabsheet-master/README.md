Installation
============

Please refer to https://gitlab.com/cjaikaeo/elab-docker for a simpler, dockerized installation.