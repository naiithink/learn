// preload navigation images
/*
if (document.images){

 var path = "";

 next_on  = new Image();
 next_on.src = path +"next_on.gif";
 next_off  = new Image();
 next_off.src = path + "next_off.gif";
 
 prev_on  = new Image();
 prev_on.src = path + "prev_on.gif";
 prev_off  = new Image();
 prev_off.src = path + "prev_off.gif";
}
*/

function HiLight(imgDocID,imgObjName) {
}